# Global Electronics Retailer: End-to-End Databricks Pipeline

A medallion-architecture data pipeline built on Databricks with PySpark and Delta Lake. It ingests raw retail CSV files, cleans them, models them as a star schema, and serves business KPIs through a Databricks dashboard. A Databricks Job runs the pipeline automatically when new files arrive.

---

## 1. Overview

**Business problem.** A global electronics retailer sells products online and through physical stores in many countries. Leadership wants a trustworthy view of revenue, orders, average order value, profitability, and top-performing products and regions.

**What this project delivers.**
- A repeatable Bronze → Silver → Gold pipeline written in PySpark
- A star schema (one fact table, three dimension tables) stored as Delta tables
- A Databricks dashboard built directly on the Gold tables
- Automated runs through a three-task Databricks Job (Bronze → Silver → Gold) with a file arrival trigger

**Dataset.** Global Electronics Retailer from Maven Analytics: `Sales`, `Customers`, `Products`, `Stores` and `Exchange_Rates` CSV files.

**Tech stack.** Databricks (Unity Catalog, Delta Lake, Jobs, dashboards, Genie), PySpark, Git folders and GitHub.

---

## 2. Architecture

```mermaid
flowchart LR
    A[CSV files<br/>Unity Catalog volume] --> B[Bronze<br/>raw, as-is]
    B --> C[Silver<br/>cleaned, typed, deduplicated]
    C --> D[Gold<br/>fact and dimension tables]
    D --> E[Databricks dashboard]
    F[File arrival trigger] -.-> B
```

| Layer | Schema | Purpose | Tables |
|---|---|---|---|
| Raw | `bronze.raw_files` (volume) | Landing zone for the source CSVs | 5 CSV files |
| Bronze | `bronze` | Raw data loaded to Delta with no business logic | `sales`, `customers`, `products`, `stores`, `exchange_rates` |
| Silver | `silver` | Typed, trimmed, deduplicated data | same five tables |
| Gold | `gold` | Business-ready star schema | `fact_sales`, `dim_products`, `dim_customers`, `dim_stores` |

---

## 3. Pipeline in detail

### 3.1 Bronze: ingest raw data

Each CSV is read from the volume and written to a Delta table with as little change as possible.

- **All columns stay as strings** (`inferSchema=False`). Bronze never fails or silently alters data because of a type guess. Typing happens in Silver.
- **Encoding `ISO-8859-1`.** The default UTF-8 corrupted accented characters in customer and store names.
- **Column names converted to snake_case** with a regex function that handles camelCase and spaces, so every later layer uses consistent names.
- **Lineage columns added:** `_sourcefile` (which file the row came from) and `_ingest_time` (when it was loaded), so any row can be traced back to its source.
- **`overwrite` with `overwriteSchema`.** The notebook can be re-run safely without creating duplicates.
- **Row counts verified** against the source files after loading.

### 3.2 Silver: clean and standardise

Cleaning is built from small reusable PySpark functions. Each does one job and takes a list of columns, so the same function is applied across tables.

| Function | What it does |
|---|---|
| `clean_text_columns` | Trims every string column and converts empty strings to null |
| `cast_to_int` | Casts the listed columns to integer |
| `parse_dates` | Converts strings such as `1/13/2016` to dates using the `M/d/yyyy` format |
| `clean_money` | Removes `$` and `,` from price columns, then casts to decimal |
| `remove_duplicates` | Drops duplicates on the table's business key |
| `count_null_keys` | Reports nulls in key columns |

Business keys used for deduplication:

| Table | Key |
|---|---|
| sales | `order_number` + `line_item` |
| products | `product_key` |
| customers | `customer_key` |
| stores | `store_key` |
| exchange_rates | `date` + `currency` |

Resulting Silver types: dates as `date`, quantities as `integer`, prices and exchange rates as `decimal(10,3)`. Key columns remain strings and are consistent across all tables, so joins match without conversion.

### 3.3 Gold: dimensional model

| Table | Grain (one row per) | Contents |
|---|---|---|
| `fact_sales` | order line (`order_number` + `line_item`) | Keys, dates, quantity, currency code and calculated measures |
| `dim_products` | product | Name, brand, color, category, subcategory, unit price and cost |
| `dim_customers` | customer | Name, gender, location, birthday |
| `dim_stores` | store | Country, state, size, open date |

**Measures in `fact_sales`**, calculated once in the pipeline:
- `revenue_usd = quantity × unit_price_usd`
- `cost_usd = quantity × unit_cost_usd`
- `profit_usd = revenue_usd − cost_usd`
- `profit_margin = profit_usd ÷ revenue_usd` (row level, rounded to 4 decimals)
- `order_month`: first day of the order's month, to simplify monthly reporting

**How the fact table was built.** `silver.sales` was left-joined to the products table to bring in unit price and cost, the measures were added, and the helper price columns and lineage columns were dropped. The three dimension tables are the Silver tables with their lineage columns removed.

**Exchange rates.** Unit prices and costs are already in USD, so the core measures do not need exchange rates. The table stays in long format (`date`, `currency`, `exchange`), which joins cleanly to sales on date and currency if a local-currency measure is added later.

---

## 4. Key design decisions

1. **Medallion layers.** Each layer has one job: Bronze preserves, Silver cleans, Gold serves. A problem can be traced to the layer where it appeared.
2. **Strings in Bronze, types in Silver.** Raw loading never fails on bad data, and type errors surface in a controlled place.
3. **Reusable cleaning functions.** One function per cleaning step, parameterised by column list, instead of repeating the same code for each table.
4. **Left joins from the fact table.** A left join keeps every sale. An inner join would silently drop sales with a missing dimension key and understate revenue.
5. **Dimension keys checked before joining.** A duplicated key silently multiplies fact rows and inflates revenue.
6. **Measures stored in the fact table.** Revenue, cost and profit are calculated once at the order-line grain. This costs a few numeric columns and avoids recomputing the same multiplication in every query.
7. **Descriptive attributes stay in dimensions.** Names, categories and countries are not copied into the fact table, which keeps it lean and easy to maintain.
8. **KPI definitions that avoid common errors.** Orders are counted with distinct order numbers, because one order can have several line items. Profit margin is total profit divided by total revenue, not an average of row margins, which would weight small and large orders equally.
9. **Dashboard built directly on Gold.** At this data size, aggregating in dashboard queries is simple and fast, so separate KPI tables were not needed.

---

## 5. Data quality and validation

Checks run during the build:

| Check | Layer | Result |
|---|---|---|
| Row counts match the source CSV files | Bronze | Passed |
| Row count unchanged after joining sales to products | Gold | Passed |
| No sales without a matching product (no null prices after the join) | Gold | Passed |
| Row count of each saved Gold table matches the DataFrame written | Gold | Passed |
| Dashboard totals are consistent: revenue − cost = profit, profit ÷ revenue = margin, revenue ÷ orders = average order value | Dashboard | Passed |

---

## 6. Orchestration

The pipeline is orchestrated by a Databricks Job, **GER_Pipeline_Orchestration**, made of three dependent tasks running on serverless compute. Each task runs only if the one before it succeeds.

| Task | Notebook | Depends on |
|---|---|---|
| `Run_Bronze_Layer` | `01_Bronze_Layer` | none |
| `Run_Silver_Layer` | `02_Silver_Layer` | `Run_Bronze_Layer` |
| `Run_Gold_Layer` | `03_gold_Layer` | `Run_Silver_Layer` |

The job uses a **file arrival trigger** on the Unity Catalog volume, so new files landing in the volume start a run without manual action.

![Job orchestration](docs/images/job_orchestration.png)

---

## 7. Dashboard

The **Global Electronics Retailer Dashboard** is built in Databricks on top of the Gold tables. Visuals were created with Genie, which writes the queries against `fact_sales` and the dimension tables directly.

![Dashboard](docs/images/dashboard.png)

**Headline KPIs**

| KPI | Definition | Value |
|---|---|---|
| Total revenue | `SUM(revenue_usd)` | $32.98M |
| Total cost | `SUM(cost_usd)` | $23.09M |
| Total profit | `SUM(profit_usd)` | $9.89M |
| Total orders | distinct `order_number` | 26.33k |
| Profit margin | total profit ÷ total revenue | 30% |
| Average order value | total revenue ÷ total orders | $1.25k |

**Visuals**

| Visual | Source tables |
|---|---|
| Top 10 products by revenue | `fact_sales`, `dim_products` |
| Profit by product category | `fact_sales`, `dim_products` |
| Profit trend by order year | `fact_sales` |
| Profit by brand | `fact_sales`, `dim_products` |
| Revenue by store country (map) | `fact_sales`, `dim_stores` |

---

## 8. How to run

Repository layout:

```
notebooks/
├── 01_Bronze_Layer
├── 02_Silver_Layer
└── 03_gold_Layer
docs/
└── images/        # dashboard and job screenshots
README.md
```

1. Clone the repository into a Databricks Git folder.
2. Create a catalog with the `bronze`, `silver` and `gold` schemas, and a volume named `raw_files` in the `bronze` schema.
3. Upload the five CSV files to the volume.
4. Run the notebooks in order: Bronze, Silver, then Gold. Alternatively, run the `GER_Pipeline_Orchestration` job, which also starts when new files arrive in the volume.
5. Open the dashboard.

---

## 9. Lessons learned

- **Check the grain before joining.** Knowing what one row means in each table prevents duplicated rows and wrong totals.
- **Spark is lazy.** `filter`, `select` and `withColumn` only build a plan. Actions such as `count` and `display` run it.
- **Plain strings and `F.col()` are not interchangeable everywhere.** Inside `.otherwise()`, a plain string is written as literal text, which fails silently and produces wrong data.
- **Encoding matters.** Reading with the wrong encoding corrupts text without raising an error.
- **Calculate measures once, in the pipeline.** Row-level revenue, cost and profit live in `fact_sales`, so every chart sums the same columns.
- **Verify after every step.** Row counts, null counts and spot checks caught problems early.
- **Check AI-generated queries.** Genie sped up building the dashboard, but KPIs such as distinct order counts and margin ratios still need to be checked against known totals.

---

## 10. Future improvements

- Add pre-aggregated KPI tables in Gold so KPI definitions live in the pipeline
- Move the transformation functions into a shared Python module with `pytest` unit tests
- Add data quality expectations and a quarantine table for rejected rows
- Add a `dim_date` calendar table
- Add a local-currency revenue measure using the exchange rate table
- Load the Gold model into a Postgres serving layer
- Add CI/CD with automated checks on pull requests

---

## 11. Author

**Gopi Syamkumar**, Data Engineer.
